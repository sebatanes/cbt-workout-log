export type MoodType = 1 | 2 | 3 | 4 | 5;

export interface StudyEntry {
  id: string;
  date: string;
  topic: string;
  duration: number;
  moodBefore: MoodType;
  moodAfter: MoodType;
  thoughts: string;
  strategies: string[];
  challenges: string;
  solutions: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudyEntryFormData {
  topic: string;
  duration: number;
  moodBefore: MoodType;
  moodAfter: MoodType;
  thoughts: string;
  strategies: string[];
  challenges: string;
  solutions: string;
}