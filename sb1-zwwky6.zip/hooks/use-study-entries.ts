"use client";

import { useState, useEffect } from 'react';
import { StudyEntry, StudyEntryFormData } from '@/lib/types';
import { toast } from 'sonner';

export function useStudyEntries() {
  const [entries, setEntries] = useState<StudyEntry[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('study-entries');
    if (stored) {
      try {
        setEntries(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to parse stored entries:', e);
      }
    }
  }, []);

  const saveEntries = (newEntries: StudyEntry[]) => {
    setEntries(newEntries);
    localStorage.setItem('study-entries', JSON.stringify(newEntries));
  };

  const addEntry = (data: StudyEntryFormData) => {
    const newEntry: StudyEntry = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    saveEntries([newEntry, ...entries]);
    toast.success('Study session logged successfully!');
    return newEntry;
  };

  const updateEntry = (id: string, data: Partial<StudyEntryFormData>) => {
    const newEntries = entries.map((entry) =>
      entry.id === id
        ? {
            ...entry,
            ...data,
            updatedAt: new Date().toISOString(),
          }
        : entry
    );
    saveEntries(newEntries);
    toast.success('Entry updated successfully!');
  };

  const deleteEntry = (id: string) => {
    saveEntries(entries.filter((entry) => entry.id !== id));
    toast.success('Entry deleted successfully!');
  };

  const exportData = () => {
    const dataStr = JSON.stringify(entries, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `cbt-study-journal-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    toast.success('Data exported successfully!');
  };

  const importData = async (file: File) => {
    try {
      const text = await file.text();
      const imported = JSON.parse(text);
      if (Array.isArray(imported)) {
        saveEntries(imported);
        toast.success('Data imported successfully!');
      } else {
        throw new Error('Invalid data format');
      }
    } catch (e) {
      toast.error('Failed to import data. Please check the file format.');
    }
  };

  return {
    entries,
    addEntry,
    updateEntry,
    deleteEntry,
    exportData,
    importData,
  };
}