"use client";

import { format } from "date-fns";
import { BarChart, Clock, Edit2, Trash2 } from "lucide-react";
import { StudyEntry } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { StudyForm } from "./study-form";

interface StudyEntriesProps {
  entries: StudyEntry[];
  onUpdate: (id: string, data: any) => void;
  onDelete: (id: string) => void;
}

export function StudyEntries({ entries, onUpdate, onDelete }: StudyEntriesProps) {
  const getMoodEmoji = (mood: number) => {
    switch (mood) {
      case 1: return "😔";
      case 2: return "🙁";
      case 3: return "😐";
      case 4: return "🙂";
      case 5: return "😊";
      default: return "😐";
    }
  };

  return (
    <div className="space-y-4">
      {entries.map((entry) => (
        <Card key={entry.id}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{entry.topic}</CardTitle>
                <CardDescription>
                  {format(new Date(entry.date), "PPP")}
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <Edit2 className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Edit Study Session</DialogTitle>
                      <DialogDescription>
                        Update your study session details
                      </DialogDescription>
                    </DialogHeader>
                    <StudyForm
                      initialData={entry}
                      onSubmit={(data) => onUpdate(entry.id, data)}
                    />
                  </DialogContent>
                </Dialog>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onDelete(entry.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span>{entry.duration} minutes</span>
                </div>
                <div className="flex items-center gap-2">
                  <BarChart className="h-4 w-4" />
                  <span>
                    Mood: {getMoodEmoji(entry.moodBefore)} → {getMoodEmoji(entry.moodAfter)}
                  </span>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium">Thoughts and Feelings</h4>
                <p className="text-sm text-muted-foreground">{entry.thoughts}</p>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Challenges</h4>
                <p className="text-sm text-muted-foreground">{entry.challenges}</p>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Solutions</h4>
                <p className="text-sm text-muted-foreground">{entry.solutions}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}